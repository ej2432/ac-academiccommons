class GenericResource < Resource
end